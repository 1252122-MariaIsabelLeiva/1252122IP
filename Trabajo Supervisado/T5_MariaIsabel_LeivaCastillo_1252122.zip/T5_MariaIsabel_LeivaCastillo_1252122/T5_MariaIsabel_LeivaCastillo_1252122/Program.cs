﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_MariaIsabel_LeivaCastillo_1252122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //PROBLEMA NO.1
            //Ingresar tres número decimales
            Console.WriteLine("Ingrese 3 valores en centavos");

            Console.WriteLine("Ingrese el primer número:");
            double A = double.Parse(Console.ReadLine());
            Console.WriteLine("GTQ");


            Console.WriteLine("Ingrese el segundo número:");
            double B = double.Parse(Console.ReadLine());
            Console.WriteLine("GTQ");


            Console.WriteLine("Ingrese el tercer número:");
            double C = double.Parse(Console.ReadLine());
            Console.WriteLine("GTQ");


            //GTQ a USD
            A = (A / 8.73);
            B = (B / 8.73);
            C = (C / 8.73);



            double mayor = 0;
            double medio = 0;
            double menor = 0;

            if (A > B)
            {
                if (A > C)
                {
                    if (B > C)
                    {
                        mayor = A;
                        medio = B;
                        menor = C;
                    }
                    else
                    {
                        mayor = A;
                        medio = C;
                        menor = B;
                    }
                }
                else
                {
                    if (A == C)
                    {
                        mayor = A;
                        medio = C;
                        menor = B;
                    }
                    else
                    {
                        mayor = C;
                        medio = A;
                        menor = B;
                    }
                }
            }
            else
            {
                if (A == B)
                {
                    if (A > C)
                    {
                        mayor = A;
                        medio = B;
                        menor = C;
                    }
                    else
                    {
                        if (A == C)
                        {
                            mayor = A;
                            medio = B;
                            menor = C;
                        }
                        else
                        {
                            mayor = C;
                            medio = A;
                            menor = B;
                        }
                    }
                }
                else
                {
                    if (B > C)
                    {
                        if (A > C)
                        {
                            mayor = B;
                            medio = A;
                            menor = C;
                        }
                        else
                        {
                            mayor = B;
                            medio = C;
                            menor = A;
                        }
                    }
                    else
                    {
                        if (B == C)
                        {
                            mayor = B;
                            medio = C;
                            menor = A;
                        }
                        else
                        {
                            mayor = C;
                            medio = B;
                            menor = A;
                        }
                    }
                }
            }
            {
                Console.WriteLine("El resultado es: ");
                Console.WriteLine(mayor + " USD");
                Console.WriteLine(medio + " USD");
                Console.WriteLine(menor + " USD");
            }
            Console.ReadLine();

        }
        

        

    }
}
