﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_MariaIsabel_1252122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido");
            Console.WriteLine("1)Verificación de número");
            Console.WriteLine("2)Análisis día de la semana");
            Console.WriteLine(">Ingrese una opción");
            int opcion = Convert.ToInt32(Console.ReadLine());
            if (opcion == 1)
            {

                {

                    Console.WriteLine("Ingrese un número: ");
                    int numero = Convert.ToInt32(Console.ReadLine());


                    //Proceso

                    if (numero > 0)
                    {
                        Console.WriteLine("El número es positivo");
                    }
                    else if (numero < 0)
                    {
                        Console.WriteLine("El número es negativo");

                    }
                    else
                    {
                        Console.WriteLine("Es cero");
                    }
                    Console.ReadLine();
                }



            }
            else if (opcion == 2)
            {
                Console.WriteLine("Ingrese un número: ");
                int dia = Convert.ToInt32(Console.ReadLine());
                if (dia == 1)
                {
                    Console.WriteLine("Lunes");
                }
                else if (dia == 2)
                {
                    Console.WriteLine("Martes");
                }
                else if (dia == 3)
                {
                    Console.WriteLine("Miércoles");
                }
                else if (dia == 4)
                {
                    Console.WriteLine("Jueves");
                }
                else if (dia == 5)
                {
                    Console.WriteLine("Viernes");
                }
                else if (dia == 6)
                {
                    Console.WriteLine("Sábado");
                }
                else if (dia == 7)
                {
                    Console.WriteLine("Domingo");
                }
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Esta no es una opción, bobi :p");
                Console.ReadLine();
            }
   


        }
    }
}
