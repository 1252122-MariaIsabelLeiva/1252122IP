﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_parte2_MariaIsabel_LeivaCastillo_1252122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------BIENVENIDO------");
            Console.WriteLine("Ingrese monto a pagar:");
            int pago = int.Parse(Console.ReadLine());
            double descuento = 0;
 
            


            Console.ReadKey();
 

            if (pago >= 400)
            {
                if (pago < 999)
                {
                    descuento = 0.7;
                }
                else
                {
                    if (pago >= 1000)
                    {
                        if (pago < 4999)
                        {
                            descuento = 0.10;
                        }
                        else
                        {
                            if (pago >= 5000)
                            {
                                if (pago <= 15000)
                                {
                                    descuento = 0.15;
                                }
                                else // pago >15000
                                {
                                    descuento = 0.25;
                                }
                            }
                        }
                    }
                    
                }
            }
            else
            {
                Console.WriteLine("No hay descuento");
                descuento = 0;
            }
            Console.WriteLine("¿Posee código de descuento?");
            Console.WriteLine("1.Sí    2.No");
            int opcion = Convert.ToInt32(Console.ReadLine());

            if (opcion == 1)
            {
                descuento = descuento - (descuento * 0.05);
            }

            {
                Console.WriteLine("El descuento aplicado es de " + descuento );
                Console.WriteLine("Su monto total a pagar es de: " + (pago - (pago * descuento)));
            }
            Console.ReadLine();
        }
    }
}
