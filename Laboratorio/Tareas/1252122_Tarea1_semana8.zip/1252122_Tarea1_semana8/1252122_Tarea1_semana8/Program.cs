﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1252122_Tarea1_semana8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Ejercicios: Tarea-Semana 8
            { // #21 y 22
                Console.WriteLine("Ingrese un valor para x: ");
                int x = Convert.ToInt32(Console.ReadLine());

                int y1, y2, y3 = 0;

                y1 = 3 * Convert.ToInt32(Math.Pow(x, 2) - (Convert.ToInt32(Math.Pow(x, 1 / 3)) + (4 * (Math.Pow(x, 2)))));
                y2 = 4 * Convert.ToInt32(Math.Pow(x, 3)) - (3 * (Convert.ToInt32(Math.Pow(x, 2)) + (2 * x) + 5));
                y3 = 5 * (Convert.ToInt32(Math.Pow(x, 1 / 3))) + (4 * Convert.ToInt32(Math.Pow(x, 2))) + 6;

                Console.WriteLine("El resultado es: y1 = " + y1 + ", y2 = " + y2 + ", y3 = " + y3);
                Console.ReadKey();
            }

            {
                //#24
                Console.WriteLine("Ingrese el presupuesto anual: ");
                double presupuesto = Convert.ToDouble(Console.ReadLine());

                double RecursosHumanos = 0;
                double Manufactura = 0;
                double Empaquetado = 0;
                double Publicidad = 0;

                RecursosHumanos = presupuesto * 0.50;
                Manufactura = presupuesto * 0.25;
                Empaquetado = presupuesto * 0.15;
                Publicidad = presupuesto * 0.10;

                Console.WriteLine("La cantidad correspondiente a cada departamento es: ");
                Console.WriteLine("Recursos Humanos: " + RecursosHumanos);
                Console.WriteLine("Manufactura: " + Manufactura);
                Console.WriteLine("Empaquetado: " + Empaquetado);
                Console.WriteLine("Publicidad: " + Publicidad);

                Console.ReadKey();

            }
            {
                //#25
                Console.WriteLine("Ingrese su salario base: ");
                double salarioBase = Convert.ToDouble(Console.ReadLine());
                double desISSS = salarioBase * 0.09;
                double desAFP = salarioBase * 0.07;
                double desRenta = salarioBase + 0.1;
                double salarioNeto = salarioBase - (desISSS + desAFP + desRenta);

                Console.WriteLine("El salario neto es de: " + salarioNeto);
                Console.WriteLine("Los descuentos efectuados fueron: ");
                Console.WriteLine("ISSS: " + desISSS);
                Console.WriteLine("AFP: " + desAFP);
                Console.WriteLine("Renta: " + desRenta);

                Console.ReadKey();

            }
            {
                //#35
                Console.WriteLine("Ingrese dos valores a evaluar: ");
                double A = Convert.ToDouble(Console.ReadLine());
                double B = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Elija un operador matemático: 1) +, 2) -, 3) *, 4) /, 5) Mod");
                double resultado = 0;
                int opcion = 0;
                switch (opcion)
                {
                    case 1:
                        resultado = A + B;
                        break;
                    case 2:
                        resultado = A - B;

                        break;
                    case 3:
                        resultado = A * B;

                        break;
                    case 4:
                        resultado = A / B;

                        break;
                    case 5:
                        resultado = A % B;

                        break;

                        Console.WriteLine("El resultado de la operación es: " + resultado);
                        Console.ReadLine();
                }
                {
                    //11
                    Console.WriteLine("Ingrese el precio del artículo determiando: ");
                    double articulo = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Ingrese el número, de este mismo artículo, que desea comprar: ");
                    int NumArticulo = Convert.ToInt32(Console.ReadLine());



                    double subtotal = 0;
                    subtotal = articulo * NumArticulo;

                    double descIVA =  subtotal * 0.13;

                    double total = 0; 

                    if (subtotal < 1000)
                    {
                        double descExtra = 0.15;
                        total = subtotal - (subtotal * descExtra) - (subtotal - descIVA);

                    }else
                    {
                        total = subtotal - (subtotal - descIVA);
                    }

                    Console.WriteLine("Su total a pagar es: " + total);
                    Console.ReadKey();
                }
                {
                    //#13
                    int suma;
                    int n = 100;

                    suma = 0;
                    {
                        //FOR
                        

                        for (int i = 1; i <= n; i++)
                        {
                            suma = suma + i;
                        }
                        Console.WriteLine("La suma de los primeros 100 numeros naturales es de: " + suma);

                    }
                    {
                        //while 
                        int i = 0;
                        while (n <= 100)
                        {
                            suma = suma + 1;
                            i = i++;
                            Console.WriteLine("La suma de los primeros 100 numeros naturales es de: " + (n * (n + 1) / 2));
                        }
                    }
                    {
                        //do-while
                        int i = 0;
                        do
                        {
                            suma = suma + 1;
                            i = i++;
                            Console.WriteLine("La suma de los primeros 100 numeros naturales es de: " + (n * (n + 1) / 2));
                        } while (n <= 100);
                    }
                }
            }
        }
    }
}
