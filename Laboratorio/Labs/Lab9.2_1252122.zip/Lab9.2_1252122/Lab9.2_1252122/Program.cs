﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9._2_1252122
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();

            objMotocicleta.DefinirPrecio(5000);
            objMotocicleta.DefinirIVA(0.10);

            Console.WriteLine("Datos:");
            Console.WriteLine(objMotocicleta.MostrarDatos());
            Console.WriteLine("Precio sin IVA:" + objMotocicleta);
            Console.WriteLine("IVA:" + objMotocicleta.DevolverIVA());
            Console.WriteLine("Precio Final: " + objMotocicleta.PrecioConIVA());

        }
    }
}
