﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9._2_1252122
{
    internal class Motocicleta
    {
        private int Modelo = 2019;
        private double Precio = 1000;
        private string Marca = "";
        private double IVA = 0.12;

        public string MostrarDatos()
        {
            string datos = "Modelo: " + Modelo + "\n" +
                            "Precio: " + Precio + "\n" +
                            "Marca: " + Marca + "\n";
            return datos;
        }

        public void DefinirPrecio(double precio)
        {
            Precio = precio;
        }

        public void DefinirIVA(double Iva)
        {
            if(Iva > 0 && Iva < 1)
            {
                 IVA = Iva;
            }

        }

        public double PrecioSinIVA()
        {
            return Precio;
        }

        public double PrecioConIVA()
        {
            return Precio + DevolverIVA();
        }
        public double DevolverIVA()
        {
            return Precio * IVA;
        }
    }
}
