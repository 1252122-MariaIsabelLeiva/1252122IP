﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9_Area_1252122
{
    internal class Circulo
    {
        //Atributo
        private double radio;

        public Circulo(double radio)
        {
            this.radio = radio;
        }

        public double ObtenerPerimetro ()
        {
            //return: valor final de la función
            return 2 * Math.PI * radio;
        }

        public double ObtenerArea()
        {
            return Math.PI * (radio * radio);
        }

        public double ObtenerVolumen()
        {
            return 4 / 3 * Math.PI * Math.Pow(radio, 3);
        }
        
        public void CalcularGeometria(double unPerimetro, double unArea, double unVolumen) //Parámetros recibidos por el método a ejecutar
        {
            Console.WriteLine("Perímetro: " + unPerimetro);
            Console.WriteLine("Área: " + unArea);
            Console.WriteLine("Volumen: " + unVolumen);

        }
    }
}
